# Arte de Norberto · maqueta 2.5D

Arte original generado para El Conejo Norberto a partir de la propuesta visual elegida: bosque cálido, formas redondeadas y personajes con aspecto de pequeñas figuras.

| Archivo | Disposición | Contenido |
| --- | --- | --- |
| `forest.png` | Panorama opaco | Bosque de día sin objetos interactivos; se repite alternando reflejos para evitar saltos en los bordes. |
| `rabbit.png` | 4 columnas × 2 filas, RGBA | Quieto; carrera 1–3; salto ascendente; descenso; quieto alternativo; caída. Mira hacia la derecha. |
| `wolf.png` | 3 columnas × 2 filas, RGBA | Carrera 1–2; carrera con boca abierta 1–2; salto; salto con boca abierta. Mira hacia la izquierda. |
| `props.png` | 3 columnas × 2 filas, RGBA | Zanahoria; corazón; cuatro variantes de rocas. |

`rabbitScene.ts` calcula los límites de transparencia por celda una sola vez. Las animaciones de cada personaje comparten escala para mantener su tamaño entre poses. La variante nocturna del panorama se prepara en memoria; no requiere otra descarga. La versión de caché se encuentra en `ASSET_VERSION`.
