# Arte de Norberto · maqueta 2.5D

Arte original generado para El Conejo Norberto a partir de la propuesta visual elegida: bosque cálido, formas redondeadas y personajes con aspecto de pequeñas figuras.

| Archivo | Disposición | Contenido |
| --- | --- | --- |
| `forest.png` | Panorama opaco | Bosque de día sin objetos interactivos; se repite alternando reflejos para evitar saltos en los bordes. |
| `rabbit.png` | 4 columnas × 2 filas, RGBA | Quieto; carrera 1–3; salto ascendente; descenso; quieto alternativo; caída. Mira hacia la derecha. |
| `wolf.png` | 3 columnas × 2 filas, RGBA | Carrera 1–2; carrera con boca abierta 1–2; salto; salto con boca abierta. Mira hacia la izquierda. |
| `props.png` | 3 columnas × 2 filas, RGBA | Zanahoria; corazón; cuatro variantes de rocas. |

`rabbitScene.ts` calcula los límites de transparencia por celda una sola vez. Las animaciones de cada personaje comparten escala para mantener su tamaño entre poses. La variante nocturna del panorama se prepara en memoria; no requiere otra descarga. La versión de caché se encuentra en `ASSET_VERSION`.

Los lobos se calibran contra el área visible del conejo de pie: su pose de carrera ocupa el doble de área, conservando su proporción original. Esto evita que duplicar la altura vuelva enorme el cuerpo ancho del lobo. Todas sus poses comparten esa escala, tanto en Aventura como en Infinito, para Norberto y Filiberta. El cuerpo de colisión mide 110 × 68 píxeles lógicos, excluyendo puntas de las orejas y margen de la cola. Aventura permite vencer al lobo saltando sobre él.

filiberta.png: atlas RGBA de 4 × 2 con las mismas poses que Norberto, pelaje blanco y gris marmolado y ojos celestes. Generado con la herramienta integrada editando rabbit.png; conserva su estilo y disposición.

- ground-3d.png: franja de césped y sección de tierra con relieve, raíces y piedras; opaca.
- foliage-3d.png: arbustos cercanos de maqueta 3D con transparencia.
Generados con la herramienta integrada usando forest.png y props.png como referencias. Prompt: capas horizontales repetibles de terreno y arbustos con iluminación de arriba a la izquierda, volumen, textura y oclusión ambiental, sin personajes ni texto; arbustos con fondo transparente.

Variante anterior v2: ground-wide-v2.png tiene superficie de césped amplia y un borde frontal más bajo. plants-flowers-v2.png contiene cuatro columnas independientes con transparencia: margaritas, helecho, flores rosas y flores azules/amarillas. La vegetación se dibuja en grupos separados. Los archivos anteriores se conservan.
Prompt de terreno: edición 3D con 55 % superior de piso transitable amplio, huella de camino horizontal al centro y tierra por debajo del borde; detalles moderados. Prompt de plantas: atlas RGBA de cuatro grupos pequeños, variados y aireados, con flores y helecho, usando forest.png como referencia de estilo. Herramienta integrada de imágenes.

Arte activo v3: se recuperan ground-3d.png y foliage-3d.png. La cara superior del terreno ocupa 36 px lógicos, con apoyo a 24 px del fondo y 12 px antes del borde; musgo y tierra conservan su textura original. Los grupos de plants-flowers-v2.png decoran los arbustos. Piso, arbustos y flores comparten el desplazamiento completo del mundo (1:1); solo el bosque lejano conserva paralaje.

Borde integrado v4: border-plants-v1.png es un atlas RGBA de 3 columnas por 2 filas con seis matas bajas de césped, hojas, tréboles y helechos. Generado con la herramienta integrada usando foliage-3d.png y plants-flowers-v2.png como referencias; prompt completo en border-plants-v1-prompt.txt. Los grupos se superponen entre 4 y 7 píxeles lógicos sobre el borde trasero, varían de tamaño y siguen el desplazamiento del suelo. Comparten iluminación nocturna y se dibujan detrás de personajes y obstáculos.

Aventura v1: norberto-actions-v1.png y filiberta-actions-v1.png son atlas RGBA 4 × 2: agachado, deslizamiento, preparación de mordida, mordida, descanso, sueño (dos poses), despertar. adventure-props-v1.png contiene tronco horizontal, poste mordible, piedra con musgo, caja y dos poses de araña. adventure-water-v1.png es la textura opaca del río. Se generaron con la herramienta integrada a partir del arte existente. Los prompts se guardan en adventure-art-prompts.json. La animación base de carrera y salto conserva los atlas anteriores.

Las acciones se calibran con las poses extendidas de carrera y deslizamiento de ambos atlas. Comparten una escala fija: agacharse y deslizarse cambian la postura, sin encoger el personaje. Los pasos bajos dejan 52 píxeles lógicos libres para esta postura; de pie todavía requieren agacharse.

Los troncos móviles y las ramas de los pasos bajos usan el recorte horizontal original de 535 × 267 píxeles con escala uniforme.

Puente v2: `bridge-trunk-v2.png` es un tronco vertical más esbelto, con transparencia real y un recorte de 289 × 1529 píxeles. Mide 310 píxeles lógicos de alto y conserva la misma proporción durante la caída de 0,72 segundos. Rota desde su base, termina por encima del pasto y solapa ambas orillas; su apoyo y su colisión comparten las mismas dimensiones. Las zanahorias se sitúan sobre el puente. Generado con la herramienta integrada; prompt completo y modo en `story-bridge-prompts.json`.

Historia v1: `story-villain-v1.png` es un atlas RGBA de 3 columnas × 2 filas: dos pasos hacia la izquierda, pose de captura agachada, dos pasos hacia la derecha llevando la bolsa y una bolsa abierta independiente. Generado con la herramienta integrada usando las acciones de los conejos como referencia; prompt completo en `story-bridge-prompts.json`. La presentación reutiliza el bosque, el terreno y las poses de sueño/despertar de Norberto y Filiberta. Se reproduce al iniciar Aventura desde el nivel 1, dura 14 segundos y se puede omitir. Norberto empieza la historia; el selector de personajes sigue disponible en pausa y en los otros modos. La reproducción se detiene mientras la pestaña está oculta y no se repite al reintentar o pasar de nivel.

Las cajas usan su recorte original de 431 × 384 píxeles con escala uniforme y 96 píxeles lógicos de ancho. Su apoyo se sitúa 6 píxeles por debajo del vértice trasero de la cara superior para que las pilas se vean apoyadas. Hay grupos de dos y tres alturas; las cajas superiores caen si pierden su apoyo. Dos mordidas rompen cada caja y liberan tres zanahorias que salen impulsadas, caen, se recogen una sola vez y recargan el supersalto.

tunnel-boulder-v1.png es una gran roca con musgo y transparencia real, generada con la herramienta integrada usando adventure-props-v1.png como referencia de estilo. Se dibuja con escala uniforme y descansa sobre la superficie continua de pasto; bloquea el paso superior incluso con supersalto. El prompt completo y las rutas están en tunnel-boulder-v1-prompt.json.

Madrigueras v1: `burrow-mound-v1.png` es un montículo bajo de tierra con transparencia real. `ground-earth-v1.png` conserva el perfil del suelo pero reemplaza todo el verde por tierra compacta y pequeñas piedras. Ambos se generaron con la herramienta integrada; prompts completos, modo y referencias en `burrow-art-v1-prompts.json`. El jugador abre el paso con una nueva pulsación de ↓ estando sobre el montículo. La cubierta de pasto se desvanece, la cámara sigue la caída de 190 píxeles y se revela un corredor con pared, techo, piso y escalones de tierra. Al salir al nivel de la superficie se restaura la cubierta. Las zanahorias del subsuelo solo son visibles y recogibles durante esa visita. Reiniciar devuelve el piso intacto.
# Precipicios y cataratas

Madriguera unificada v2: `burrow-interior-v2.png` contiene el hueco completo, con la pared de fondo, el techo, el camino y los dos escalones esculpidos en una única pieza de tierra. Se generó con la herramienta integrada tomando la captura del túnel y `soil-deep-v1.png` como referencias; prompt completo y modo en `burrow-interior-v2-prompt.json`. Se dibuja a escala uniforme fija (900 × 600 píxeles lógicos), sin recortes independientes entre superficies. Sus márgenes se funden con el terreno exterior y las bocas usan las terminaciones de pasto existentes, con una transición suave hacia la tierra del interior. La capa de apoyo bajo el arte comparte las coordenadas y la escala de la tierra exterior, evitando franjas transparentes al suavizar una unión. La salida y sus colisiones siguen los escalones del dibujo.

Subsuelo profundo v1: `soil-deep-v1.png` es una nueva sección de tierra sin pasto, con el doble de alto que de ancho. `cliff-deep-right-v1.png` contiene una pared lateral tres veces más alta que ancha, con transparencia real; el lateral izquierdo se obtiene reflejándola en memoria. Generadas con la herramienta integrada, con los materiales anteriores como referencia; prompts y rutas en `underground-art-v1-prompts.json`. El césped y el labio existentes conservan su anchura. La tierra frontal, los fondos de excavaciones y túneles, y los laterales se dibujan con escala uniforme fija: bajar la cámara solo cambia el recorte. Los extremos muy profundos se prolongan por repetición reflejada, sin estirar. Las cataratas también conservan la escala de su caída. Pruebas de renderizado verifican que la escala no depende de la profundidad visible.

pit-earth-wall-v1.png es la pared interior de los huecos excavados: borde de pasto, tierra cálida, raíces y piedras. Sustituye al fondo de barranco para los huecos secos. El prompt y la ruta del PNG se guardan en pit-earth-wall-v1-prompt.json; se generó con la herramienta integrada usando el terreno y la captura del usuario como referencias.

cliff-left-v1.png y cliff-right-v1.png son terminaciones con transparencia real. ravine-depth-v1.png aporta la profundidad del barranco. river-waterfall-v2.png incluye superficie, espuma y caída vertical del agua. Generadas con image_gen integrado tomando el terreno existente como referencia; el conjunto de prompts y rutas está en terrain-art-prompts-v2.json. Los originales se conservan y las uniones se resuelven al dibujar el escenario.
